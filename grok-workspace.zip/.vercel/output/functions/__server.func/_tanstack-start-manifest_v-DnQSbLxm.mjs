//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DnQSbLxm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/browse",
			"/api/extract",
			"/api/media"
		],
		preloads: ["/assets/index-9UxuJMv9.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-9UxuJMv9.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BH6T6DBv.js"]
	}
} });
//#endregion
export { tsrStartManifest };
