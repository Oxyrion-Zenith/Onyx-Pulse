import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as useRouter, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-PD5_idDv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-CxY1qji6.css";
var APP_NAME = "Onyx Pulse";
var Route$4 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#09090b"
			},
			{
				name: "description",
				content: "Onyx Pulse — video and audio player with a Brave-powered browser."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		"data-theme": "onyx",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter = () => import("./routes-CnqB7oyG.mjs");
var Route$3 = createFileRoute("/")({
	ssr: false,
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	pendingComponent: Splash
});
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-background text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl font-semibold",
			children: "Onyx Pulse"
		})
	});
}
function isDirectMediaUrl(url) {
	try {
		const path = new URL(url).pathname.toLowerCase();
		return /\.(mp4|webm|mkv|mov|m4v|mp3|wav|flac|aac|ogg|opus|m4a|m3u8|mpd)(\?|$)/.test(path);
	} catch {
		return false;
	}
}
function mediaKindFromUrl(url) {
	const path = url.split("?")[0]?.toLowerCase() ?? "";
	if (/\.(mp3|wav|flac|aac|ogg|opus|m4a)$/.test(path)) return "audio";
	return "video";
}
function isHlsUrl(url) {
	return /\.m3u8(\?|$)/i.test(url) || url.includes("m3u8");
}
function youtubeId(url) {
	try {
		const u = new URL(url);
		const host = u.hostname.replace(/^www\./, "");
		if (host === "youtu.be") return u.pathname.slice(1).split("/")[0] || null;
		if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com") {
			if (u.searchParams.get("v")) return u.searchParams.get("v");
			const parts = u.pathname.split("/").filter(Boolean);
			if (parts[0] === "shorts" || parts[0] === "embed" || parts[0] === "live") return parts[1] ?? null;
		}
	} catch {
		return null;
	}
	return null;
}
function vimeoId(url) {
	try {
		const u = new URL(url);
		if (!u.hostname.includes("vimeo.com")) return null;
		const id = u.pathname.split("/").filter(Boolean).pop();
		return id && /^\d+$/.test(id) ? id : null;
	} catch {
		return null;
	}
}
function detectPlatform(url) {
	try {
		const host = new URL(url).hostname.replace(/^www\./, "");
		if (host.includes("youtube") || host === "youtu.be") return "YouTube";
		if (host.includes("vimeo")) return "Vimeo";
		if (host.includes("soundcloud")) return "SoundCloud";
		if (host.includes("tiktok")) return "TikTok";
		if (host.includes("instagram")) return "Instagram";
		if (host === "x.com" || host.includes("twitter")) return "X";
		if (host.includes("reddit") || host === "v.redd.it") return "Reddit";
		if (host.includes("dailymotion")) return "Dailymotion";
		if (host.includes("twitch")) return "Twitch";
		if (host.includes("facebook") || host === "fb.watch") return "Facebook";
		if (host.includes("archive.org")) return "Internet Archive";
		if (host.includes("bandcamp")) return "Bandcamp";
		if (isDirectMediaUrl(url)) return "Direct";
		return host;
	} catch {
		return "Unknown";
	}
}
function toEmbedUrl(url) {
	const yt = youtubeId(url);
	if (yt) return `https://www.youtube.com/embed/${yt}?rel=0&modestbranding=1`;
	const vm = vimeoId(url);
	if (vm) return `https://player.vimeo.com/video/${vm}`;
}
function normalizeUrl(input) {
	const trimmed = input.trim();
	if (!trimmed) return "";
	if (/^https?:\/\//i.test(trimmed)) return trimmed;
	if (trimmed.includes(" ") || !trimmed.includes(".")) return braveSearchUrl(trimmed);
	return `https://${trimmed}`;
}
function braveSearchUrl(q, engine = "brave") {
	const query = encodeURIComponent(q);
	if (engine === "duckduckgo") return `https://duckduckgo.com/?q=${query}`;
	if (engine === "startpage") return `https://www.startpage.com/sp/search?query=${query}`;
	return `https://search.brave.com/search?q=${query}`;
}
function hostnameOf(url) {
	try {
		return new URL(url).hostname.replace(/^www\./, "");
	} catch {
		return url;
	}
}
var PRIVATE = /^(localhost|127\.|10\.|192\.168\.|169\.254\.|0\.|::1|\[::1\])/;
var PRIVATE_HOST = /^(localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\]|::1)$/i;
function assertPublicHttpUrl(raw) {
	let url;
	try {
		url = new URL(raw);
	} catch {
		throw new Error("Invalid URL");
	}
	if (url.protocol !== "http:" && url.protocol !== "https:") throw new Error("Only http(s) URLs are allowed");
	if (PRIVATE_HOST.test(url.hostname) || PRIVATE.test(url.hostname)) throw new Error("That address is not allowed");
	return url;
}
var BROWSER_UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36 Brave/126";
async function fetchUpstream(url, init = {}) {
	const target = assertPublicHttpUrl(url);
	const headers = new Headers(init.headers);
	if (!headers.has("user-agent")) headers.set("user-agent", BROWSER_UA);
	if (!headers.has("accept")) headers.set("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
	const ctrl = new AbortController();
	const t = setTimeout(() => ctrl.abort(), 2e4);
	try {
		return await fetch(target.toString(), {
			...init,
			headers,
			redirect: "follow",
			signal: ctrl.signal
		});
	} finally {
		clearTimeout(t);
	}
}
function rewriteM3u8(text, playlistUrl) {
	const base = new URL(playlistUrl);
	return text.split("\n").map((line) => {
		const trimmed = line.trim();
		if (!trimmed || trimmed.startsWith("#")) return line.replace(/URI="([^"]+)"/g, (_, uri) => {
			const abs = new URL(uri, base).toString();
			return `URI="/api/media?url=${encodeURIComponent(abs)}"`;
		});
		const abs = new URL(trimmed, base).toString();
		return `/api/media?url=${encodeURIComponent(abs)}`;
	}).join("\n");
}
async function proxyMedia(url) {
	const res = await fetchUpstream(url, { headers: { accept: "*/*" } });
	const type = res.headers.get("content-type") ?? "application/octet-stream";
	const headers = new Headers();
	headers.set("content-type", type);
	const len = res.headers.get("content-length");
	if (len) headers.set("content-length", len);
	headers.set("cache-control", "private, max-age=120");
	headers.set("access-control-allow-origin", "*");
	if (/mpegurl|m3u8|application\/vnd\.apple\.mpegurl/i.test(type) || url.includes(".m3u8")) {
		const rewritten = rewriteM3u8(await res.text(), res.url || url);
		headers.set("content-type", "application/vnd.apple.mpegurl");
		headers.delete("content-length");
		return new Response(rewritten, {
			status: 200,
			headers
		});
	}
	return new Response(res.body, {
		status: res.status,
		headers
	});
}
function pickThumb(thumbs) {
	if (!Array.isArray(thumbs) || !thumbs.length) return void 0;
	return thumbs[thumbs.length - 1]?.url;
}
async function extractYouTube(id, pageUrl) {
	const body = {
		context: { client: {
			clientName: "ANDROID",
			clientVersion: "19.28.35",
			androidSdkVersion: 34,
			hl: "en",
			gl: "US"
		} },
		videoId: id,
		contentCheckOk: true,
		racyCheckOk: true
	};
	let data = {};
	try {
		data = await (await fetch("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", {
			method: "POST",
			headers: {
				"content-type": "application/json",
				"user-agent": "com.google.android.youtube/19.28.35 (Linux; U; Android 14) gzip",
				"x-youtube-client-name": "3",
				"x-youtube-client-version": "19.28.35"
			},
			body: JSON.stringify(body)
		})).json();
	} catch {
		data = {};
	}
	const details = data.videoDetails ?? {};
	const streaming = data.streamingData ?? {};
	const formats = [...streaming.formats ?? [], ...streaming.adaptiveFormats ?? []].map((f, i) => {
		const mime = String(f.mimeType ?? "video/mp4");
		const url = typeof f.url === "string" ? f.url : "";
		const quality = String(f.qualityLabel ?? f.audioQuality ?? "");
		return {
			id: String(f.itag ?? i),
			label: quality ? `${quality} · ${mime.split(";")[0]}` : mime.split(";")[0] ?? "media",
			mime,
			quality,
			url,
			hasAudio: mime.includes("audio") || f.audioChannels != null,
			hasVideo: mime.includes("video"),
			bitrate: typeof f.bitrate === "number" ? f.bitrate : void 0,
			contentLength: f.contentLength ? Number(f.contentLength) : void 0
		};
	}).filter((f) => f.url);
	let title = details.title;
	let author = details.author;
	let thumbnail = pickThumb(details.thumbnail?.thumbnails);
	let duration = details.lengthSeconds ? Number(details.lengthSeconds) : void 0;
	if (!title) try {
		const oe = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(pageUrl)}&format=json`);
		if (oe.ok) {
			const j = await oe.json();
			title = j.title ?? title;
			author = j.author_name ?? author;
			thumbnail = j.thumbnail_url ?? thumbnail;
		}
	} catch {}
	const combined = formats.filter((f) => f.hasAudio && f.hasVideo);
	const audioOnly = formats.filter((f) => f.hasAudio && !f.hasVideo);
	const ordered = [
		...combined,
		...audioOnly,
		...formats.filter((f) => !combined.includes(f) && !audioOnly.includes(f))
	];
	return {
		title: title ?? "YouTube video",
		author,
		thumbnail,
		duration,
		platform: "YouTube",
		pageUrl,
		embedUrl: `https://www.youtube.com/embed/${id}?rel=0&modestbranding=1`,
		formats: ordered,
		note: ordered.length ? void 0 : "YouTube did not return a direct file. You can still play it in the library via the embedded player."
	};
}
async function extractVimeo(id, pageUrl) {
	let title = "Vimeo video";
	let author;
	let thumbnail;
	const formats = [];
	try {
		const cfg = await fetch(`https://player.vimeo.com/video/${id}/config`, { headers: { "user-agent": BROWSER_UA } });
		if (cfg.ok) {
			const j = await cfg.json();
			title = j.video?.title ?? title;
			author = j.video?.owner?.name;
			thumbnail = j.video?.thumbs?.base ?? Object.values(j.video?.thumbs ?? {})[0];
			for (const p of j.request?.files?.progressive ?? []) formats.push({
				id: p.quality,
				label: `${p.quality} · mp4`,
				mime: p.mime ?? "video/mp4",
				quality: p.quality,
				url: p.url,
				hasAudio: true,
				hasVideo: true
			});
		}
	} catch {}
	return {
		title,
		author,
		thumbnail,
		platform: "Vimeo",
		pageUrl,
		embedUrl: `https://player.vimeo.com/video/${id}`,
		formats
	};
}
function absUrl(maybe, base) {
	try {
		return new URL(maybe, base).toString();
	} catch {
		return null;
	}
}
async function extractGeneric(pageUrl) {
	const platform = detectPlatform(pageUrl);
	if (isDirectMediaUrl(pageUrl)) {
		const name = decodeURIComponent(pageUrl.split("/").pop()?.split("?")[0] ?? "Media");
		const isAudio = /\.(mp3|wav|flac|aac|ogg|opus|m4a)(\?|$)/i.test(pageUrl);
		return {
			title: name,
			platform,
			pageUrl,
			formats: [{
				id: "direct",
				label: isAudio ? "Audio file" : "Video file",
				mime: isAudio ? "audio/*" : "video/*",
				url: pageUrl,
				hasAudio: true,
				hasVideo: !isAudio
			}]
		};
	}
	const res = await fetchUpstream(pageUrl);
	const type = res.headers.get("content-type") ?? "";
	if (/video|audio|mpegurl|ogg|webm|mp4/i.test(type) && !/html/i.test(type)) return {
		title: decodeURIComponent(pageUrl.split("/").pop()?.split("?")[0] ?? "Media"),
		platform,
		pageUrl,
		formats: [{
			id: "direct",
			label: type.split(";")[0] ?? "Media",
			mime: type,
			url: res.url || pageUrl,
			hasAudio: /audio/i.test(type),
			hasVideo: /video/i.test(type)
		}]
	};
	const html = (await res.text()).slice(0, 15e5);
	const finalUrl = res.url || pageUrl;
	const formats = [];
	const seen = /* @__PURE__ */ new Set();
	const push = (raw, label, mime = "video/mp4") => {
		const url = absUrl(raw.replace(/&/g, "&"), finalUrl);
		if (!url || seen.has(url)) return;
		if (!/^https?:/i.test(url)) return;
		seen.add(url);
		const isAudio = /audio|\.mp3|\.m4a|\.ogg|\.flac|\.wav/i.test(url + mime);
		const isHls = /\.m3u8/i.test(url);
		formats.push({
			id: `src_${formats.length}`,
			label: isHls ? `${label} · HLS` : label,
			mime: isHls ? "application/vnd.apple.mpegurl" : mime,
			url,
			hasAudio: true,
			hasVideo: !isAudio
		});
	};
	const ogTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)/i)?.[1];
	const ogVideo = html.match(/<meta[^>]+property=["']og:video(?::url)?["'][^>]+content=["']([^"']+)/i)?.[1] ?? html.match(/<meta[^>]+property=["']og:audio["'][^>]+content=["']([^"']+)/i)?.[1];
	const ogImage = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)/i)?.[1];
	const titleTag = html.match(/<title[^>]*>([^<]+)/i)?.[1];
	const twitterPlayer = html.match(/<meta[^>]+name=["']twitter:player:stream["'][^>]+content=["']([^"']+)/i)?.[1];
	if (ogVideo) push(ogVideo, "Open Graph", "video/mp4");
	if (twitterPlayer) push(twitterPlayer, "Stream", "video/mp4");
	const sourceRe = /<(?:source|video|audio)[^>]+src=["']([^"']+)["'][^>]*>/gi;
	let m;
	while (m = sourceRe.exec(html)) {
		const src = m[1];
		if (src) push(src, "Page source");
	}
	const fileRe = /https?:\/\/[^\s"'<>]+?\.(?:mp4|webm|m3u8|mp3|m4a|aac|ogg|wav|flac)(?:\?[^\s"'<>]*)?/gi;
	while (m = fileRe.exec(html)) if (m[0]) push(m[0], "Linked file");
	const jsonLd = [...html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)];
	for (const block of jsonLd) try {
		const data = JSON.parse(block[1] ?? "null");
		const nodes = Array.isArray(data) ? data : [data];
		for (const node of nodes) {
			const content = node.contentUrl ?? node.embedUrl ?? node.url;
			if (typeof content === "string") push(content, "Structured data");
		}
	} catch {}
	return {
		title: decodeHtml(ogTitle || titleTag || hostnameTitle(finalUrl)),
		thumbnail: ogImage ? absUrl(ogImage, finalUrl) ?? void 0 : void 0,
		platform,
		pageUrl: finalUrl,
		embedUrl: toEmbedUrl(finalUrl),
		formats,
		note: formats.length ? void 0 : "No direct media file was found on this page. You can still save it as a playable link."
	};
}
function decodeHtml(s) {
	return s.replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/"/g, "\"").replace(/&#39;/g, "'").replace(/\s+/g, " ").trim();
}
function hostnameTitle(url) {
	try {
		return new URL(url).hostname.replace(/^www\./, "");
	} catch {
		return "Media";
	}
}
async function extractMedia(pageUrl) {
	const url = assertPublicHttpUrl(pageUrl).toString();
	const yt = youtubeId(url);
	if (yt) return extractYouTube(yt, url);
	const vm = vimeoId(url);
	if (vm) return extractVimeo(vm, url);
	return extractGeneric(url);
}
var TRACKER_RE = new RegExp(`(google-analytics\\.com|googletagmanager\\.com|doubleclick\\.net|facebook\\.net|scorecardresearch\\.com|googlesyndication\\.com|hotjar\\.com)`, "i");
async function browsePage(pageUrl, shields) {
	const res = await fetchUpstream(pageUrl);
	const type = res.headers.get("content-type") ?? "text/html";
	if (!/html/i.test(type)) {
		const headers = new Headers();
		headers.set("content-type", type);
		const len = res.headers.get("content-length");
		if (len) headers.set("content-length", len);
		headers.set("x-frame-options", "ALLOWALL");
		headers.set("content-security-policy", "frame-ancestors *");
		return new Response(res.body, {
			status: res.status,
			headers
		});
	}
	let html = await res.text();
	const finalUrl = res.url || pageUrl;
	const origin = new URL(finalUrl);
	html = html.replace(/<meta[^>]+http-equiv=["']refresh["'][^>]*>/gi, "");
	html = html.replace(/<base[^>]*>/i, "");
	if (shields) html = html.replace(/<script[^>]+src=["'][^"']+["'][^>]*>\s*<\/script>/gi, (tag) => TRACKER_RE.test(tag) ? "" : tag);
	const interceptor = `<base href="${origin.href}">
<script>
(function(){
  try {
    Object.defineProperty(window, 'top', { get: function(){ return window.self; } });
    Object.defineProperty(window, 'parent', { get: function(){ return window.self; } });
  } catch (e) {}
  function proxied(u){
    try {
      var abs = new URL(u, ${JSON.stringify(origin.href)}).toString();
      if (abs.indexOf('/api/browse') !== -1) return abs;
      return '/api/browse?url=' + encodeURIComponent(abs);
    } catch(e) { return u; }
  }
  document.addEventListener('click', function(e){
    var a = e.target && e.target.closest ? e.target.closest('a') : null;
    if (!a || !a.href) return;
    if (a.target === '_blank') return;
    var href = a.getAttribute('href');
    if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0) return;
    e.preventDefault();
    location.href = proxied(a.href);
  }, true);
  document.addEventListener('submit', function(e){
    var form = e.target;
    if (!form || !form.action) return;
    try {
      var action = form.getAttribute('action') || ${JSON.stringify(origin.href)};
      form.setAttribute('action', proxied(action));
    } catch (err) {}
  }, true);
  window.addEventListener('load', function(){
    try {
      parent.postMessage({ type: 'onyx-browse', title: document.title, url: ${JSON.stringify(finalUrl)} }, '*');
    } catch (e) {}
  });
})();
<\/script>`;
	if (/<head[^>]*>/i.test(html)) html = html.replace(/<head[^>]*>/i, (h) => `${h}\n${interceptor}`);
	else html = interceptor + html;
	const headers = new Headers();
	headers.set("content-type", "text/html; charset=utf-8");
	headers.set("content-security-policy", "frame-ancestors *");
	headers.set("x-frame-options", "ALLOWALL");
	headers.set("cache-control", "private, max-age=30");
	return new Response(html, {
		status: 200,
		headers
	});
}
var Route$2 = createFileRoute("/api/browse")({ server: { handlers: { GET: async ({ request }) => {
	const parsed = new URL(request.url);
	const url = parsed.searchParams.get("url");
	const shields = parsed.searchParams.get("shields") !== "0";
	if (!url) return new Response("Missing url", { status: 400 });
	try {
		return await browsePage(url, shields);
	} catch (err) {
		const message = err instanceof Error ? err.message : "Browse failed";
		return new Response(`<!doctype html><html><body style="font-family:system-ui;background:#09090b;color:#f4f4f1;padding:32px">
              <h1 style="font-size:18px">This page could not be opened</h1>
              <p style="color:#a1a19a">${message}</p>
            </body></html>`, {
			status: 200,
			headers: { "content-type": "text/html; charset=utf-8" }
		});
	}
} } } });
var Route$1 = createFileRoute("/api/extract")({ server: { handlers: {
	GET: async ({ request }) => {
		const url = new URL(request.url).searchParams.get("url");
		if (!url) return Response.json({ error: "Missing url" }, { status: 400 });
		try {
			const result = await extractMedia(url);
			return Response.json(result);
		} catch (err) {
			const message = err instanceof Error ? err.message : "Extract failed";
			return Response.json({ error: message }, { status: 400 });
		}
	},
	POST: async ({ request }) => {
		let body = {};
		try {
			body = await request.json();
		} catch {
			return Response.json({ error: "Invalid JSON" }, { status: 400 });
		}
		if (!body.url) return Response.json({ error: "Missing url" }, { status: 400 });
		try {
			const result = await extractMedia(body.url);
			return Response.json(result);
		} catch (err) {
			const message = err instanceof Error ? err.message : "Extract failed";
			return Response.json({ error: message }, { status: 400 });
		}
	}
} } });
var Route = createFileRoute("/api/media")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url).searchParams.get("url");
	if (!url) return new Response("Missing url", { status: 400 });
	try {
		return await proxyMedia(url);
	} catch (err) {
		const message = err instanceof Error ? err.message : "Proxy failed";
		return new Response(message, { status: 400 });
	}
} } } });
var rootRouteChildren = {
	IndexRoute: Route$3.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$4
	}),
	ApiBrowseRoute: Route$2.update({
		id: "/api/browse",
		path: "/api/browse",
		getParentRoute: () => Route$4
	}),
	ApiExtractRoute: Route$1.update({
		id: "/api/extract",
		path: "/api/extract",
		getParentRoute: () => Route$4
	}),
	ApiMediaRoute: Route.update({
		id: "/api/media",
		path: "/api/media",
		getParentRoute: () => Route$4
	})
};
var routeTree = Route$4._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { isDirectMediaUrl as a, normalizeUrl as c, hostnameOf as i, toEmbedUrl as l, braveSearchUrl as n, isHlsUrl as o, detectPlatform as r, mediaKindFromUrl as s, router_exports as t };
