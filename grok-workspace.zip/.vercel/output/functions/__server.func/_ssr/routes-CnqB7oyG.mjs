import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { A as Image, B as Check, C as Pause, D as LoaderCircle, E as Lock, F as EyeOff, H as ArrowLeft, I as Download, L as Compass, M as FolderOpen, N as FolderInput, O as Link2, P as FastForward, R as ChevronRight, S as PictureInPicture2, T as Maximize, V as ArrowRight, _ as Repeat, b as Plus, c as SkipForward, d as Shield, f as ShieldOff, g as Rewind, h as RotateCw, i as Upload, j as House, k as LayoutGrid, l as SkipBack, m as Search, n as VolumeX, o as Trash2, p as Settings, r as Volume2, s as Star, t as X, u as Shuffle, v as Repeat1, w as Music4, x as Play, y as Radio, z as ChevronDown } from "../_libs/lucide-react.mjs";
import { a as isDirectMediaUrl, c as normalizeUrl, i as hostnameOf, l as toEmbedUrl, n as braveSearchUrl, o as isHlsUrl, r as detectPlatform, s as mediaKindFromUrl } from "./router-PD5_idDv.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as Hls } from "../_libs/hls.js.mjs";
import { t as require_js } from "../_libs/lamejs.mjs";
import { n as Root, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CnqB7oyG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_js = /* @__PURE__ */ __toESM(require_js());
var now = Date.now();
var SAMPLE_LIBRARY = [
	{
		id: "sample_bbb",
		title: "Big Buck Bunny",
		artist: "Blender Foundation",
		kind: "video",
		source: "sample",
		url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
		thumbnail: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg",
		duration: 596,
		createdAt: now - 3456e5,
		platform: "Direct"
	},
	{
		id: "sample_elephants",
		title: "Elephants Dream",
		artist: "Blender Foundation",
		kind: "video",
		source: "sample",
		url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
		thumbnail: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg",
		duration: 653,
		createdAt: now - 2592e5,
		platform: "Direct"
	},
	{
		id: "sample_sintel",
		title: "Sintel",
		artist: "Blender Foundation",
		kind: "video",
		source: "sample",
		url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
		thumbnail: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/Sintel.jpg",
		duration: 888,
		createdAt: now - 1728e5,
		platform: "Direct"
	},
	{
		id: "sample_tears",
		title: "Tears of Steel",
		artist: "Blender Foundation",
		kind: "video",
		source: "sample",
		url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
		thumbnail: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/TearsOfSteel.jpg",
		duration: 734,
		createdAt: now - 864e5,
		platform: "Direct"
	},
	{
		id: "sample_forbigger",
		title: "For Bigger Blazes",
		artist: "Google",
		kind: "video",
		source: "sample",
		url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
		thumbnail: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerBlazes.jpg",
		duration: 15,
		createdAt: now - 36e5,
		platform: "Direct"
	}
];
var SAMPLE_STREAMS = [
	{
		id: "stream_paradise",
		name: "Radio Paradise",
		url: "https://stream.radioparadise.com/aac-320",
		kind: "audio",
		createdAt: now
	},
	{
		id: "stream_soma",
		name: "SomaFM Groove Salad",
		url: "https://ice1.somafm.com/groovesalad-128-mp3",
		kind: "audio",
		createdAt: now
	},
	{
		id: "stream_mux",
		name: "Mux HLS Test",
		url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
		kind: "hls",
		createdAt: now
	}
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}
var defaultSettings = {
	autoplay: true,
	resumePlayback: true,
	searchEngine: "brave",
	defaultQuality: "auto",
	shields: true,
	reduceMotion: false,
	eqEnabled: false,
	eqPreset: "flat"
};
var defaultWidgets = {
	nowPlaying: true,
	continueWatching: true,
	quickConvert: true,
	downloads: true,
	liveRadio: true
};
var useAppStore = create()(persist((set, get) => ({
	hydrated: false,
	view: "home",
	theme: "onyx",
	library: [],
	streams: [],
	downloads: [],
	bookmarks: [
		{
			id: "bm_wiki",
			title: "Wikipedia",
			url: "https://en.wikipedia.org/wiki/Main_Page",
			createdAt: Date.now()
		},
		{
			id: "bm_archive",
			title: "Internet Archive",
			url: "https://archive.org/",
			createdAt: Date.now()
		},
		{
			id: "bm_brave",
			title: "Brave Search",
			url: "https://search.brave.com/",
			createdAt: Date.now()
		}
	],
	history: [],
	tabs: [{
		id: "tab_home",
		url: "onyx://newtab",
		title: "New tab"
	}],
	activeTabId: "tab_home",
	widgets: defaultWidgets,
	settings: defaultSettings,
	hiddenPinHash: null,
	hiddenUnlocked: false,
	currentId: null,
	queue: [],
	shuffle: false,
	repeat: "off",
	volume: .85,
	muted: false,
	rate: 1,
	playing: false,
	playerOpen: false,
	seeded: false,
	setHydrated: () => set({ hydrated: true }),
	setView: (view) => set({
		view,
		playerOpen: view === "player"
	}),
	setTheme: (theme) => set({ theme }),
	addMedia: (item) => set((s) => ({ library: [item, ...s.library.filter((m) => m.id !== item.id)] })),
	updateMedia: (id, patch) => set((s) => ({ library: s.library.map((m) => m.id === id ? {
		...m,
		...patch
	} : m) })),
	removeMedia: (id) => set((s) => ({
		library: s.library.filter((m) => m.id !== id),
		queue: s.queue.filter((q) => q !== id),
		currentId: s.currentId === id ? null : s.currentId
	})),
	addStream: (item) => set((s) => ({ streams: [item, ...s.streams] })),
	removeStream: (id) => set((s) => ({ streams: s.streams.filter((x) => x.id !== id) })),
	addDownload: (item) => set((s) => ({ downloads: [item, ...s.downloads] })),
	updateDownload: (id, patch) => set((s) => ({ downloads: s.downloads.map((d) => d.id === id ? {
		...d,
		...patch
	} : d) })),
	removeDownload: (id) => set((s) => ({ downloads: s.downloads.filter((d) => d.id !== id) })),
	clearFinishedDownloads: () => set((s) => ({ downloads: s.downloads.filter((d) => d.status === "downloading" || d.status === "queued") })),
	addBookmark: (b) => set((s) => ({ bookmarks: [b, ...s.bookmarks] })),
	removeBookmark: (id) => set((s) => ({ bookmarks: s.bookmarks.filter((b) => b.id !== id) })),
	pushHistory: (b) => set((s) => ({ history: [b, ...s.history.filter((h) => h.url !== b.url)].slice(0, 80) })),
	setTabs: (tabs) => set({ tabs }),
	setActiveTab: (id) => set({ activeTabId: id }),
	updateTab: (id, patch) => set((s) => ({ tabs: s.tabs.map((t) => t.id === id ? {
		...t,
		...patch
	} : t) })),
	setWidgets: (w) => set((s) => ({ widgets: {
		...s.widgets,
		...w
	} })),
	setSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch
	} })),
	setHiddenPinHash: (hash) => set({ hiddenPinHash: hash }),
	setHiddenUnlocked: (v) => set({ hiddenUnlocked: v }),
	playItem: (id, queue) => {
		const lib = get().library;
		const item = lib.find((m) => m.id === id);
		const q = queue ?? lib.filter((m) => !m.hidden && m.kind === item?.kind).map((m) => m.id);
		set({
			currentId: id,
			queue: q.length ? q : [id],
			playing: true,
			playerOpen: true,
			view: "player"
		});
	},
	setPlaying: (v) => set({ playing: v }),
	setPlayerOpen: (v) => set({ playerOpen: v }),
	toggleShuffle: () => set((s) => ({ shuffle: !s.shuffle })),
	cycleRepeat: () => set((s) => ({ repeat: s.repeat === "off" ? "all" : s.repeat === "all" ? "one" : "off" })),
	setVolume: (v) => set({
		volume: v,
		muted: v === 0 ? true : false
	}),
	setMuted: (v) => set({ muted: v }),
	setRate: (v) => set({ rate: v }),
	playNext: () => {
		const { queue, currentId, shuffle, repeat } = get();
		if (!queue.length) return;
		const idx = queue.indexOf(currentId ?? "");
		if (repeat === "one" && currentId) {
			set({ playing: true });
			return;
		}
		let next;
		if (shuffle) {
			const rest = queue.filter((id) => id !== currentId);
			next = rest[Math.floor(Math.random() * rest.length)] ?? currentId ?? void 0;
		} else {
			next = queue[idx + 1];
			if (!next && repeat === "all") next = queue[0];
		}
		if (next) set({
			currentId: next,
			playing: true,
			playerOpen: true,
			view: "player"
		});
		else set({ playing: false });
	},
	playPrev: () => {
		const { queue, currentId } = get();
		const prev = queue[queue.indexOf(currentId ?? "") - 1] ?? queue[0];
		if (prev) set({
			currentId: prev,
			playing: true,
			playerOpen: true,
			view: "player"
		});
	},
	seedIfNeeded: () => {
		if (get().seeded) return;
		set({
			seeded: true,
			library: SAMPLE_LIBRARY,
			streams: SAMPLE_STREAMS
		});
	}
}), {
	name: "onyx-pulse",
	partialize: (s) => ({
		theme: s.theme,
		library: s.library,
		streams: s.streams,
		downloads: s.downloads.map((d) => d.status === "downloading" ? {
			...d,
			status: "error",
			error: "Interrupted"
		} : d),
		bookmarks: s.bookmarks,
		history: s.history,
		widgets: s.widgets,
		settings: s.settings,
		hiddenPinHash: s.hiddenPinHash,
		volume: s.volume,
		muted: s.muted,
		rate: s.rate,
		shuffle: s.shuffle,
		repeat: s.repeat,
		seeded: s.seeded,
		currentId: s.currentId,
		queue: s.queue
	}),
	onRehydrateStorage: () => (state) => {
		state?.setHydrated();
		state?.seedIfNeeded();
	}
}));
function newTab(url = "onyx://newtab") {
	return {
		id: uid("tab"),
		url,
		title: url === "onyx://newtab" ? "New tab" : "Loading"
	};
}
function formatTime(seconds) {
	if (seconds == null || !Number.isFinite(seconds) || seconds < 0) return "0:00";
	const s = Math.floor(seconds);
	const h = Math.floor(s / 3600);
	const m = Math.floor(s % 3600 / 60);
	const sec = s % 60;
	if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
	return `${m}:${String(sec).padStart(2, "0")}`;
}
function formatBytes(bytes) {
	if (bytes == null || !Number.isFinite(bytes) || bytes <= 0) return "—";
	const units = [
		"B",
		"KB",
		"MB",
		"GB"
	];
	let n = bytes;
	let i = 0;
	while (n >= 1024 && i < units.length - 1) {
		n /= 1024;
		i += 1;
	}
	return `${n < 10 && i > 0 ? n.toFixed(1) : Math.round(n)} ${units[i]}`;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground hover:opacity-90",
			outline: "surface-ring bg-transparent hover:bg-secondary",
			ghost: "hover:bg-secondary",
			destructive: "bg-destructive text-primary-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-md px-3 text-xs",
			lg: "h-12 rounded-lg px-5",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1 w-full grow overflow-hidden rounded-full bg-secondary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-3.5 rounded-full bg-primary shadow-sm ring-offset-background transition-transform focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none" })]
}));
Slider.displayName = Slider$1.displayName;
var EQ_FREQUENCIES = [
	60,
	170,
	350,
	1e3,
	3500,
	1e4
];
var EQ_PRESETS = {
	flat: [
		0,
		0,
		0,
		0,
		0,
		0
	],
	bass: [
		6,
		4,
		1,
		0,
		-1,
		-2
	],
	voice: [
		-2,
		-1,
		2,
		4,
		3,
		0
	],
	treble: [
		-2,
		-1,
		0,
		1,
		4,
		6
	],
	night: [
		2,
		1,
		0,
		0,
		-2,
		-4
	]
};
var DB_NAME = "onyx-pulse";
var STORE = "blobs";
var VERSION = 1;
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, VERSION);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
async function putMediaBlob(id, blob) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(blob, id);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
	db.close();
}
async function getMediaBlob(id) {
	const db = await openDb();
	const blob = await new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).get(id);
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
	db.close();
	return blob;
}
async function deleteMediaBlob(id) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete(id);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
	db.close();
}
function proxyUrl(url) {
	if (!url) return "";
	if (url.startsWith("blob:") || url.startsWith("data:") || url.startsWith("/")) return url;
	return `/api/media?url=${encodeURIComponent(url)}`;
}
async function resolvePlayable(item) {
	if (item.embedUrl && !item.url && !item.blobId) return {
		src: null,
		embed: item.embedUrl,
		hls: false
	};
	if (item.blobId) {
		const blob = await getMediaBlob(item.blobId);
		if (blob) {
			const objectUrl = URL.createObjectURL(blob);
			return {
				src: objectUrl,
				embed: null,
				hls: blob.type.includes("mpegurl"),
				objectUrl
			};
		}
	}
	if (item.url) return {
		src: proxyUrl(item.url),
		embed: item.embedUrl ?? null,
		hls: isHlsUrl(item.url)
	};
	if (item.embedUrl) return {
		src: null,
		embed: item.embedUrl,
		hls: false
	};
	return {
		src: null,
		embed: null,
		hls: false
	};
}
var PlayerContext = (0, import_react.createContext)(null);
function usePlayer() {
	const ctx = (0, import_react.useContext)(PlayerContext);
	if (!ctx) throw new Error("usePlayer must be used within PlayerProvider");
	return ctx;
}
function PlayerProvider({ children }) {
	const videoRef = (0, import_react.useRef)(null);
	const hlsRef = (0, import_react.useRef)(null);
	const audioRef = (0, import_react.useRef)(null);
	const objectUrlRef = (0, import_react.useRef)(null);
	const [analyser, setAnalyser] = (0, import_react.useState)(null);
	const [currentTime, setCurrentTime] = (0, import_react.useState)(0);
	const [duration, setDuration] = (0, import_react.useState)(0);
	const [buffered, setBuffered] = (0, import_react.useState)(0);
	const [embedUrl, setEmbedUrl] = (0, import_react.useState)(null);
	const [waiting, setWaiting] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const currentId = useAppStore((s) => s.currentId);
	const library = useAppStore((s) => s.library);
	const playing = useAppStore((s) => s.playing);
	const volume = useAppStore((s) => s.volume);
	const muted = useAppStore((s) => s.muted);
	const rate = useAppStore((s) => s.rate);
	const settings = useAppStore((s) => s.settings);
	const view = useAppStore((s) => s.view);
	const playNext = useAppStore((s) => s.playNext);
	const setPlaying = useAppStore((s) => s.setPlaying);
	const updateMedia = useAppStore((s) => s.updateMedia);
	const current = (0, import_react.useMemo)(() => library.find((m) => m.id === currentId) ?? null, [library, currentId]);
	const theater = view === "player" && current?.kind === "video" && !embedUrl;
	const ensureGraph = (0, import_react.useCallback)(() => {
		const video = videoRef.current;
		if (!video || audioRef.current) return audioRef.current;
		try {
			const ctx = new AudioContext();
			const source = ctx.createMediaElementSource(video);
			const filters = EQ_FREQUENCIES.map((freq) => {
				const f = ctx.createBiquadFilter();
				f.type = "peaking";
				f.frequency.value = freq;
				f.Q.value = 1;
				f.gain.value = 0;
				return f;
			});
			const node = ctx.createAnalyser();
			node.fftSize = 256;
			node.smoothingTimeConstant = .82;
			let prev = source;
			for (const f of filters) {
				prev.connect(f);
				prev = f;
			}
			prev.connect(node);
			node.connect(ctx.destination);
			audioRef.current = {
				ctx,
				analyser: node,
				filters
			};
			setAnalyser(node);
		} catch {}
		return audioRef.current;
	}, []);
	(0, import_react.useEffect)(() => {
		const graph = audioRef.current;
		if (!graph) return;
		const gains = settings.eqEnabled ? EQ_PRESETS[settings.eqPreset] : EQ_PRESETS.flat;
		graph.filters.forEach((f, i) => {
			f.gain.value = gains[i] ?? 0;
		});
	}, [settings.eqEnabled, settings.eqPreset]);
	(0, import_react.useEffect)(() => {
		const media = videoRef.current;
		if (!media) return;
		let cancelled = false;
		async function load(el) {
			setError(null);
			setEmbedUrl(null);
			setWaiting(true);
			hlsRef.current?.destroy();
			hlsRef.current = null;
			if (objectUrlRef.current) {
				URL.revokeObjectURL(objectUrlRef.current);
				objectUrlRef.current = null;
			}
			if (!current) {
				el.removeAttribute("src");
				el.load();
				setWaiting(false);
				return;
			}
			try {
				const resolved = await resolvePlayable(current);
				if (cancelled) {
					if (resolved.objectUrl) URL.revokeObjectURL(resolved.objectUrl);
					return;
				}
				if (resolved.objectUrl) objectUrlRef.current = resolved.objectUrl;
				if (resolved.embed && !resolved.src) {
					setEmbedUrl(resolved.embed);
					setWaiting(false);
					setPlaying(false);
					return;
				}
				if (!resolved.src) {
					setError("Nothing to play");
					setWaiting(false);
					return;
				}
				el.crossOrigin = "anonymous";
				if (resolved.hls && Hls.isSupported()) {
					const hls = new Hls({
						enableWorker: true,
						maxBufferLength: 30
					});
					hls.loadSource(resolved.src);
					hls.attachMedia(el);
					hlsRef.current = hls;
				} else el.src = resolved.src;
				ensureGraph();
				if (useAppStore.getState().playing) {
					await audioRef.current?.ctx.resume();
					await el.play().catch(() => setPlaying(false));
				}
			} catch (err) {
				if (!cancelled) {
					setError(err instanceof Error ? err.message : "Could not load media");
					if (current.embedUrl) setEmbedUrl(current.embedUrl);
				}
			} finally {
				if (!cancelled) setWaiting(false);
			}
		}
		load(media);
		return () => {
			cancelled = true;
		};
	}, [
		current,
		ensureGraph,
		setPlaying
	]);
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video) return;
		video.volume = volume;
		video.muted = muted;
		video.playbackRate = rate;
	}, [
		volume,
		muted,
		rate
	]);
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video || embedUrl) return;
		if (playing) {
			audioRef.current?.ctx.resume();
			video.play().catch(() => setPlaying(false));
		} else video.pause();
	}, [
		playing,
		embedUrl,
		setPlaying
	]);
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video) return;
		const onTime = () => setCurrentTime(video.currentTime);
		const onDur = () => {
			setDuration(video.duration || 0);
			if (current && Number.isFinite(video.duration) && video.duration > 0) updateMedia(current.id, { duration: video.duration });
		};
		const onProg = () => {
			try {
				if (video.buffered.length) setBuffered(video.buffered.end(video.buffered.length - 1));
			} catch {}
		};
		const onEnd = () => playNext();
		const onWait = () => setWaiting(true);
		const onPlay = () => {
			setWaiting(false);
			setPlaying(true);
		};
		const onPause = () => setPlaying(false);
		const onErr = () => setError("Playback failed");
		video.addEventListener("timeupdate", onTime);
		video.addEventListener("durationchange", onDur);
		video.addEventListener("progress", onProg);
		video.addEventListener("ended", onEnd);
		video.addEventListener("waiting", onWait);
		video.addEventListener("playing", onPlay);
		video.addEventListener("pause", onPause);
		video.addEventListener("error", onErr);
		return () => {
			video.removeEventListener("timeupdate", onTime);
			video.removeEventListener("durationchange", onDur);
			video.removeEventListener("progress", onProg);
			video.removeEventListener("ended", onEnd);
			video.removeEventListener("waiting", onWait);
			video.removeEventListener("playing", onPlay);
			video.removeEventListener("pause", onPause);
			video.removeEventListener("error", onErr);
		};
	}, [
		current,
		playNext,
		setPlaying,
		updateMedia
	]);
	const seek = (0, import_react.useCallback)((t) => {
		const video = videoRef.current;
		if (!video || !Number.isFinite(t)) return;
		video.currentTime = Math.max(0, t);
		setCurrentTime(video.currentTime);
	}, []);
	const toggle = (0, import_react.useCallback)(() => {
		const next = !useAppStore.getState().playing;
		setPlaying(next);
	}, [setPlaying]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA" || e.target?.isContentEditable) return;
			if (e.code === "Space") {
				e.preventDefault();
				toggle();
			} else if (e.code === "ArrowRight") seek(currentTime + 10);
			else if (e.code === "ArrowLeft") seek(currentTime - 10);
			else if (e.key === "m" || e.key === "M") useAppStore.getState().setMuted(!useAppStore.getState().muted);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		currentTime,
		seek,
		toggle
	]);
	const api = (0, import_react.useMemo)(() => ({
		videoRef,
		analyser,
		current,
		currentTime,
		duration,
		buffered,
		embedUrl,
		waiting,
		error,
		seek,
		toggle
	}), [
		analyser,
		current,
		currentTime,
		duration,
		buffered,
		embedUrl,
		waiting,
		error,
		seek,
		toggle
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PlayerContext.Provider, {
		value: api,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			ref: videoRef,
			playsInline: true,
			controls: false,
			preload: "metadata",
			className: theater ? "pointer-events-none fixed inset-0 z-20 h-full w-full bg-black object-contain" : "pointer-events-none fixed top-0 left-0 z-0 h-px w-px opacity-0"
		}), children]
	});
}
function Visualizer({ className = "" }) {
	const canvasRef = (0, import_react.useRef)(null);
	const { analyser } = usePlayer();
	const playing = useAppStore((s) => s.playing);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		const data = analyser ? new Uint8Array(analyser.frequencyBinCount) : /* @__PURE__ */ new Uint8Array(64);
		const draw = () => {
			const { width, height } = canvas;
			ctx.clearRect(0, 0, width, height);
			if (analyser && playing) analyser.getByteFrequencyData(data);
			else data.fill(playing ? 40 : 12);
			const bars = 48;
			const gap = 3;
			const bw = (width - 141) / bars;
			const step = Math.max(1, Math.floor(data.length / bars));
			for (let i = 0; i < bars; i++) {
				const v = data[i * step] ?? 0;
				const h = Math.max(4, v / 255 * height * .85);
				const x = i * (bw + gap);
				const y = (height - h) / 2;
				ctx.globalAlpha = .35 + v / 255 * .65;
				ctx.fillStyle = getComputedStyle(canvas).color;
				ctx.beginPath();
				ctx.roundRect(x, y, bw, h, 2);
				ctx.fill();
			}
			raf = requestAnimationFrame(draw);
		};
		const resize = () => {
			const rect = canvas.getBoundingClientRect();
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			canvas.width = Math.floor(rect.width * dpr);
			canvas.height = Math.floor(rect.height * dpr);
		};
		resize();
		const ro = new ResizeObserver(resize);
		ro.observe(canvas);
		raf = requestAnimationFrame(draw);
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
		};
	}, [analyser, playing]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvasRef,
		className: `text-primary ${className}`
	});
}
function FullPlayer() {
	const { videoRef, current, currentTime, duration, buffered, embedUrl, waiting, error, seek, toggle } = usePlayer();
	const playing = useAppStore((s) => s.playing);
	const shuffle = useAppStore((s) => s.shuffle);
	const repeat = useAppStore((s) => s.repeat);
	const volume = useAppStore((s) => s.volume);
	const muted = useAppStore((s) => s.muted);
	const rate = useAppStore((s) => s.rate);
	const setView = useAppStore((s) => s.setView);
	const playNext = useAppStore((s) => s.playNext);
	const playPrev = useAppStore((s) => s.playPrev);
	const toggleShuffle = useAppStore((s) => s.toggleShuffle);
	const cycleRepeat = useAppStore((s) => s.cycleRepeat);
	const setVolume = useAppStore((s) => s.setVolume);
	const setMuted = useAppStore((s) => s.setMuted);
	const setRate = useAppStore((s) => s.setRate);
	const setPlayerOpen = useAppStore((s) => s.setPlayerOpen);
	const isVideo = current?.kind === "video" && !embedUrl;
	if (!current) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl",
				children: "Nothing is playing"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Open the library and pick a title."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setView("library"),
				children: "Go to library"
			})
		]
	});
	const progress = duration > 0 ? currentTime / duration * 100 : 0;
	const bufferedPct = duration > 0 ? buffered / duration * 100 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative z-30 flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 bg-gradient-to-b from-background via-background/90 to-transparent px-3 pt-3 pb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "Close player",
						onClick: () => {
							setPlayerOpen(false);
							setView("library");
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-display text-sm font-semibold",
							children: current.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: current.artist ?? current.platform ?? "Onyx Pulse"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-9 rounded-md bg-secondary px-2 text-xs",
						value: rate,
						onChange: (e) => setRate(Number(e.target.value)),
						"aria-label": "Playback speed",
						children: [
							.5,
							.75,
							1,
							1.25,
							1.5,
							1.75,
							2
						].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: r,
							children: [r, "×"]
						}, r))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex min-h-0 w-full max-w-5xl flex-1 items-center justify-center px-4",
				children: [
					embedUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
						title: current.title,
						src: embedUrl,
						className: "aspect-video w-full rounded-xl bg-black shadow-[var(--shadow-border)]",
						allow: "autoplay; fullscreen; picture-in-picture",
						allowFullScreen: true
					}) : isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-video w-full" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-full w-full max-w-lg flex-col items-center justify-center gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative size-56 overflow-hidden rounded-2xl bg-secondary shadow-[var(--shadow-border)]",
							children: current.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: current.thumbnail,
								alt: "",
								className: "h-full w-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-full w-full items-center justify-center bg-subtle",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-5xl text-muted-foreground",
									children: current.title.slice(0, 1)
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Visualizer, { className: "h-24 w-full" })]
					}),
					waiting && !embedUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute bottom-2 text-xs text-muted-foreground",
						children: "Loading…"
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute bottom-2 text-xs text-destructive",
						children: error
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-gradient-to-t from-background via-background/95 to-transparent px-5 pt-8 pb-[calc(1.25rem+env(safe-area-inset-bottom))]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto w-full max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "relative h-1.5 overflow-hidden rounded-full bg-secondary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute inset-y-0 left-0 bg-foreground/20",
										style: { width: `${bufferedPct}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									className: "-mt-1.5",
									min: 0,
									max: 1e3,
									step: 1,
									value: [progress * 10],
									onValueChange: ([v]) => seek((v ?? 0) / 1e3 * (duration || 0)),
									"aria-label": "Seek"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex justify-between text-[11px] tabular-nums text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTime(currentTime) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTime(duration) })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-center gap-1 sm:gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Shuffle",
									onClick: toggleShuffle,
									className: shuffle ? "text-primary" : "text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Previous",
									onClick: playPrev,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Back 10 seconds",
									onClick: () => seek(currentTime - 10),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rewind, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									className: "size-14 rounded-full",
									"aria-label": playing ? "Pause" : "Play",
									onClick: toggle,
									children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-6 translate-x-px" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Forward 10 seconds",
									onClick: () => seek(currentTime + 10),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FastForward, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Next",
									onClick: playNext,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Repeat",
									onClick: cycleRepeat,
									className: repeat === "off" ? "text-muted-foreground" : "text-primary",
									children: repeat === "one" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat1, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-4" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-sm",
									"aria-label": muted ? "Unmute" : "Mute",
									onClick: () => setMuted(!muted),
									children: muted || volume === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									min: 0,
									max: 100,
									value: [muted ? 0 : volume * 100],
									onValueChange: ([v]) => setVolume((v ?? 0) / 100),
									"aria-label": "Volume"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-sm",
									"aria-label": "Picture in picture",
									onClick: () => {
										const v = videoRef.current;
										if (v && document.pictureInPictureEnabled) v.requestPictureInPicture();
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PictureInPicture2, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-sm",
									"aria-label": "Fullscreen",
									onClick: () => {
										const v = videoRef.current;
										if (!v) return;
										if (document.fullscreenElement) document.exitFullscreen();
										else v.requestFullscreen();
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, { className: "size-4" })
								})
							]
						})
					]
				})
			})
		]
	});
}
function MiniPlayer() {
	const { current, toggle } = usePlayer();
	const playing = useAppStore((s) => s.playing);
	const view = useAppStore((s) => s.view);
	const setView = useAppStore((s) => s.setView);
	const playNext = useAppStore((s) => s.playNext);
	const setPlaying = useAppStore((s) => s.setPlaying);
	const setPlayerOpen = useAppStore((s) => s.setPlayerOpen);
	if (!current || view === "player") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-t border-border bg-card/95 px-3 py-2 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex min-w-0 flex-1 items-center gap-3 text-left",
					onClick: () => {
						setPlayerOpen(true);
						setView("player");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-11 shrink-0 overflow-hidden rounded-md bg-secondary",
						children: current.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: current.thumbnail,
							alt: "",
							className: "h-full w-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-full w-full items-center justify-center text-xs text-muted-foreground",
							children: current.kind === "audio" ? "A" : "V"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium",
							children: current.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: current.artist ?? current.platform ?? "Now playing"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-full bg-primary text-primary-foreground",
					"aria-label": playing ? "Pause" : "Play",
					onClick: toggle,
					children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 translate-x-px" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-full text-foreground",
					"aria-label": "Next",
					onClick: playNext,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-full text-muted-foreground",
					"aria-label": "Stop",
					onClick: () => {
						setPlaying(false);
						setPlayerOpen(false);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})
			]
		})
	});
}
async function fetchToBlob(url, onProgress) {
	const res = await fetch(proxyUrl(url));
	if (!res.ok) throw new Error(`Download failed (${res.status})`);
	const total = Number(res.headers.get("content-length") ?? 0) || void 0;
	const type = res.headers.get("content-type") ?? "application/octet-stream";
	if (!res.body) {
		const buf = await res.arrayBuffer();
		onProgress?.(1, buf.byteLength, buf.byteLength);
		return new Blob([buf], { type });
	}
	const reader = res.body.getReader();
	const chunks = [];
	let received = 0;
	for (;;) {
		const { done, value } = await reader.read();
		if (done) break;
		if (value) {
			chunks.push(value);
			received += value.byteLength;
			onProgress?.(total ? received / total : .5, received, total);
		}
	}
	onProgress?.(1, received, total ?? received);
	const bytes = new Uint8Array(received);
	let offset = 0;
	for (const c of chunks) {
		bytes.set(c, offset);
		offset += c.byteLength;
	}
	return new Blob([bytes], { type });
}
async function saveBlobAsMedia(blob, meta) {
	const id = uid("media");
	const blobId = uid("blob");
	await putMediaBlob(blobId, blob);
	const kind = meta.kind ?? (blob.type.startsWith("audio") ? "audio" : blob.type.startsWith("video") ? "video" : meta.sourceUrl ? mediaKindFromUrl(meta.sourceUrl) : "video");
	return {
		id,
		title: meta.title,
		artist: meta.artist,
		kind,
		source: "local",
		url: meta.sourceUrl ?? "",
		blobId,
		thumbnail: meta.thumbnail,
		createdAt: Date.now(),
		hidden: meta.hidden,
		platform: meta.platform,
		mime: blob.type,
		size: blob.size
	};
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/60 data-[state=open]:animate-in", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed top-1/2 left-1/2 z-50 w-[min(100%-2rem,28rem)] -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-card p-5 text-card-foreground shadow-[var(--shadow-border)]", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-3 right-3 rounded-md p-2 text-muted-foreground hover:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 space-y-1", className),
		...props
	});
}
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-lg font-semibold", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
function ExtractDialog({ open, onOpenChange, result }) {
	const addMedia = useAppStore((s) => s.addMedia);
	const addDownload = useAppStore((s) => s.addDownload);
	const updateDownload = useAppStore((s) => s.updateDownload);
	const playItem = useAppStore((s) => s.playItem);
	const [busy, setBusy] = (0, import_react.useState)(null);
	if (!result) return null;
	const data = result;
	async function saveFormat(fmt) {
		const dlId = uid("dl");
		setBusy(fmt.id);
		addDownload({
			id: dlId,
			title: data.title,
			url: fmt.url,
			status: "downloading",
			progress: 0,
			createdAt: Date.now(),
			format: fmt.label
		});
		try {
			const item = await saveBlobAsMedia(await fetchToBlob(fmt.url, (ratio, bytes, total) => {
				updateDownload(dlId, {
					progress: ratio,
					bytes,
					totalBytes: total
				});
			}), {
				title: data.title,
				artist: data.author,
				kind: fmt.hasVideo ? "video" : "audio",
				thumbnail: data.thumbnail,
				platform: data.platform,
				sourceUrl: data.pageUrl
			});
			addMedia(item);
			updateDownload(dlId, {
				status: "done",
				progress: 1,
				mediaId: item.id
			});
			onOpenChange(false);
			playItem(item.id);
		} catch (err) {
			updateDownload(dlId, {
				status: "error",
				error: err instanceof Error ? err.message : "Download failed"
			});
		} finally {
			setBusy(null);
		}
	}
	function saveAsLink() {
		const id = uid("media");
		addMedia({
			id,
			title: data.title,
			artist: data.author,
			kind: "video",
			source: "embed",
			url: data.pageUrl,
			thumbnail: data.thumbnail,
			duration: data.duration,
			createdAt: Date.now(),
			platform: data.platform,
			embedUrl: data.embedUrl
		});
		onOpenChange(false);
		playItem(id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "pr-6",
				children: data.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [data.author ? `${data.author} · ` : "", data.platform] })] }),
			data.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: data.thumbnail,
				alt: "",
				className: "mb-3 aspect-video w-full rounded-lg object-cover"
			}) : null,
			data.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-xs text-muted-foreground",
				children: data.note
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex max-h-56 flex-col gap-2 overflow-y-auto",
				children: data.formats.map((fmt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: busy !== null,
					onClick: () => void saveFormat(fmt),
					className: "flex items-center justify-between rounded-lg bg-secondary px-3 py-3 text-left text-sm hover:bg-subtle disabled:opacity-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 truncate",
						children: fmt.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-3 flex items-center gap-2 text-xs text-muted-foreground",
						children: [fmt.contentLength ? formatBytes(fmt.contentLength) : null, busy === fmt.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })]
					})]
				}, fmt.id))
			}),
			data.embedUrl || data.pageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "mt-3 w-full",
				onClick: saveAsLink,
				children: "Save as playable link"
			}) : null
		] })
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	className: cn("flex h-11 w-full rounded-lg bg-secondary px-3 text-sm text-foreground shadow-[var(--shadow-border)] outline-none transition-[box-shadow] placeholder:text-fg-subtle focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50", className),
	ref,
	...props
}));
Input.displayName = "Input";
var SPEED_DIAL = [
	{
		title: "Brave Search",
		url: "https://search.brave.com/"
	},
	{
		title: "Wikipedia",
		url: "https://en.wikipedia.org/wiki/Main_Page"
	},
	{
		title: "Internet Archive",
		url: "https://archive.org/"
	},
	{
		title: "MDN",
		url: "https://developer.mozilla.org/"
	},
	{
		title: "BBC",
		url: "https://www.bbc.com/"
	},
	{
		title: "Open Library",
		url: "https://openlibrary.org/"
	}
];
function BrowserView() {
	const tabs = useAppStore((s) => s.tabs);
	const activeTabId = useAppStore((s) => s.activeTabId);
	const setTabs = useAppStore((s) => s.setTabs);
	const setActiveTab = useAppStore((s) => s.setActiveTab);
	const updateTab = useAppStore((s) => s.updateTab);
	const bookmarks = useAppStore((s) => s.bookmarks);
	const addBookmark = useAppStore((s) => s.addBookmark);
	const pushHistory = useAppStore((s) => s.pushHistory);
	const settings = useAppStore((s) => s.settings);
	const setSettings = useAppStore((s) => s.setSettings);
	const tab = tabs.find((t) => t.id === activeTabId) ?? tabs[0];
	const [draft, setDraft] = (0, import_react.useState)(tab?.url === "onyx://newtab" ? "" : tab?.url ?? "");
	const [extract, setExtract] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [extracting, setExtracting] = (0, import_react.useState)(false);
	const [historyStack, setHistoryStack] = (0, import_react.useState)(["onyx://newtab"]);
	const [histIndex, setHistIndex] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!tab) return;
		setDraft(tab.url === "onyx://newtab" ? "" : tab.url);
	}, [tab?.id, tab?.url]);
	(0, import_react.useEffect)(() => {
		const onMsg = (e) => {
			const data = e.data;
			if (data?.type !== "onyx-browse" || !tab) return;
			if (data.title) updateTab(tab.id, {
				title: data.title,
				loading: false
			});
			if (data.url) {
				updateTab(tab.id, { url: data.url });
				pushHistory({
					id: uid("hist"),
					title: data.title ?? data.url,
					url: data.url,
					createdAt: Date.now()
				});
			}
		};
		window.addEventListener("message", onMsg);
		return () => window.removeEventListener("message", onMsg);
	}, [
		tab,
		updateTab,
		pushHistory
	]);
	const frameSrc = (0, import_react.useMemo)(() => {
		if (!tab || tab.url === "onyx://newtab") return null;
		const shields = settings.shields ? "1" : "0";
		return `/api/browse?url=${encodeURIComponent(tab.url)}&shields=${shields}`;
	}, [tab, settings.shields]);
	function navigate(raw, push = true) {
		if (!tab) return;
		const href = normalizeUrl(raw) || braveSearchUrl(raw, settings.searchEngine);
		updateTab(tab.id, {
			url: href,
			title: hostnameOf(href),
			loading: true
		});
		if (push) {
			const next = [...historyStack.slice(0, histIndex + 1), href];
			setHistoryStack(next);
			setHistIndex(next.length - 1);
		}
		pushHistory({
			id: uid("hist"),
			title: hostnameOf(href),
			url: href,
			createdAt: Date.now()
		});
	}
	function goBack() {
		if (histIndex <= 0) return;
		const next = histIndex - 1;
		setHistIndex(next);
		const url = historyStack[next];
		if (url && tab) updateTab(tab.id, {
			url,
			title: hostnameOf(url)
		});
	}
	function goForward() {
		if (histIndex >= historyStack.length - 1) return;
		const next = histIndex + 1;
		setHistIndex(next);
		const url = historyStack[next];
		if (url && tab) updateTab(tab.id, {
			url,
			title: hostnameOf(url)
		});
	}
	async function downloadCurrent() {
		if (!tab || tab.url === "onyx://newtab") return;
		setExtracting(true);
		try {
			const res = await fetch("/api/extract", {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({ url: tab.url })
			});
			const data = await res.json();
			if (!res.ok) throw new Error(data.error ?? "No media found");
			setExtract(data);
			setOpen(true);
		} catch (err) {
			setExtract({
				title: tab.title || tab.url,
				platform: hostnameOf(tab.url),
				pageUrl: tab.url,
				formats: [],
				note: err instanceof Error ? err.message : "No downloadable media on this page."
			});
			setOpen(true);
		} finally {
			setExtracting(false);
		}
	}
	function bookmarkCurrent() {
		if (!tab || tab.url === "onyx://newtab") return;
		addBookmark({
			id: uid("bm"),
			title: tab.title,
			url: tab.url,
			createdAt: Date.now()
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1 overflow-x-auto border-b border-border px-2 pt-2",
				children: [tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setActiveTab(t.id),
					className: `flex h-9 max-w-[11rem] items-center gap-2 rounded-t-lg px-3 text-xs ${t.id === activeTabId ? "bg-card" : "text-muted-foreground hover:bg-secondary"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: t.title || "Tab"
					}), tabs.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						role: "button",
						tabIndex: 0,
						className: "rounded p-0.5 hover:bg-subtle",
						onClick: (e) => {
							e.stopPropagation();
							const next = tabs.filter((x) => x.id !== t.id);
							setTabs(next);
							if (t.id === activeTabId && next[0]) setActiveTab(next[0].id);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
					}) : null]
				}, t.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mb-1 flex size-8 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary",
					"aria-label": "New tab",
					onClick: () => {
						const t = newTab();
						setTabs([...tabs, t]);
						setActiveTab(t.id);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1 bg-card px-2 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Back",
						onClick: goBack,
						disabled: histIndex <= 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Forward",
						onClick: goForward,
						disabled: histIndex >= historyStack.length - 1,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Reload",
						onClick: () => tab && tab.url !== "onyx://newtab" && updateTab(tab.id, { url: tab.url }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex min-w-0 flex-1 items-center gap-2 rounded-full bg-secondary px-3",
						onSubmit: (e) => {
							e.preventDefault();
							navigate(draft);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-primary",
							"aria-label": settings.shields ? "Shields on" : "Shields off",
							onClick: () => setSettings({ shields: !settings.shields }),
							children: settings.shields ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft,
							onChange: (e) => setDraft(e.target.value),
							placeholder: "Search Brave or enter address",
							className: "h-10 border-0 bg-transparent shadow-none focus-visible:ring-0"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Bookmark",
						onClick: bookmarkCurrent,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => void downloadCurrent(),
						disabled: extracting || tab?.url === "onyx://newtab",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Download"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative min-h-0 flex-1 bg-background",
				children: frameSrc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					title: tab?.title ?? "Browser",
					src: frameSrc,
					className: "h-full w-full bg-background",
					sandbox: "allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
				}, frameSrc) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewTab, {
					engine: settings.searchEngine,
					bookmarks,
					onGo: (u) => navigate(u)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExtractDialog, {
				open,
				onOpenChange: setOpen,
				result: extract
			})
		]
	});
}
function NewTab({ engine, bookmarks, onGo }) {
	const [q, setQ] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-full max-w-lg flex-col items-center px-5 pt-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6 flex size-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
					className: "size-8",
					strokeWidth: 1.6
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-semibold",
				children: "Onyx Browser"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Brave Search · Shields on by default"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
				className: "mt-6 w-full",
				onSubmit: (e) => {
					e.preventDefault();
					onGo(q.trim() ? braveSearchUrl(q, engine) : "https://search.brave.com/");
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search the web with Brave",
					className: "h-12 rounded-full px-5"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid w-full grid-cols-3 gap-3",
				children: SPEED_DIAL.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onGo(s.url),
					className: "rounded-xl bg-card px-2 py-4 text-center text-xs shadow-[var(--shadow-border)]",
					children: s.title
				}, s.url))
			}),
			bookmarks.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs tracking-wide text-muted-foreground uppercase",
					children: "Bookmarks"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-1",
					children: bookmarks.slice(0, 8).map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onGo(b.url),
						className: "truncate rounded-lg px-2 py-2 text-left text-sm hover:bg-secondary",
						children: b.title
					}, b.id))
				})]
			}) : null
		]
	});
}
function floatTo16(input) {
	const out = new Int16Array(input.length);
	for (let i = 0; i < input.length; i++) {
		const s = Math.max(-1, Math.min(1, input[i] ?? 0));
		out[i] = s < 0 ? s * 32768 : s * 32767;
	}
	return out;
}
function writeString(view, offset, str) {
	for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
}
function audioBufferToWav(buffer) {
	const numChannels = buffer.numberOfChannels;
	const sampleRate = buffer.sampleRate;
	const format = 1;
	const bitDepth = 16;
	const blockAlign = numChannels * (bitDepth / 8);
	const length = buffer.length * blockAlign;
	const arrayBuffer = new ArrayBuffer(44 + length);
	const view = new DataView(arrayBuffer);
	writeString(view, 0, "RIFF");
	view.setUint32(4, 36 + length, true);
	writeString(view, 8, "WAVE");
	writeString(view, 12, "fmt ");
	view.setUint32(16, 16, true);
	view.setUint16(20, format, true);
	view.setUint16(22, numChannels, true);
	view.setUint32(24, sampleRate, true);
	view.setUint32(28, sampleRate * blockAlign, true);
	view.setUint16(32, blockAlign, true);
	view.setUint16(34, bitDepth, true);
	writeString(view, 36, "data");
	view.setUint32(40, length, true);
	const channels = [];
	for (let c = 0; c < numChannels; c++) channels.push(buffer.getChannelData(c));
	let offset = 44;
	for (let i = 0; i < buffer.length; i++) for (let c = 0; c < numChannels; c++) {
		const sample = Math.max(-1, Math.min(1, channels[c]?.[i] ?? 0));
		view.setInt16(offset, sample < 0 ? sample * 32768 : sample * 32767, true);
		offset += 2;
	}
	return new Blob([arrayBuffer], { type: "audio/wav" });
}
function audioBufferToMp3(buffer, onProgress) {
	const channels = buffer.numberOfChannels >= 2 ? 2 : 1;
	const encoder = new import_js.default.Mp3Encoder(channels, buffer.sampleRate, 192);
	const left = floatTo16(buffer.getChannelData(0));
	const right = channels === 2 ? floatTo16(buffer.getChannelData(1)) : void 0;
	const block = 1152;
	const parts = [];
	for (let i = 0; i < left.length; i += block) {
		const l = left.subarray(i, i + block);
		const r = right ? right.subarray(i, i + block) : void 0;
		const chunk = r ? encoder.encodeBuffer(l, r) : encoder.encodeBuffer(l);
		if (chunk.length > 0) parts.push(chunk);
		onProgress?.(Math.min(1, i / left.length));
	}
	const flush = encoder.flush();
	if (flush.length > 0) parts.push(flush);
	onProgress?.(1);
	return new Blob(parts, { type: "audio/mpeg" });
}
async function decodeMediaFile(file) {
	const ctx = new AudioContext();
	try {
		const data = await file.arrayBuffer();
		return await ctx.decodeAudioData(data.slice(0));
	} finally {
		await ctx.close().catch(() => void 0);
	}
}
async function convertToAudio(file, format, onProgress) {
	onProgress?.(.05);
	const audio = await decodeMediaFile(file);
	onProgress?.(.4);
	if (format === "wav") {
		const blob = audioBufferToWav(audio);
		onProgress?.(1);
		return {
			blob,
			mime: "audio/wav",
			ext: "wav"
		};
	}
	return {
		blob: audioBufferToMp3(audio, (n) => onProgress?.(.4 + n * .6)),
		mime: "audio/mpeg",
		ext: "mp3"
	};
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 2500);
}
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("relative h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full bg-primary transition-transform duration-200",
		style: { transform: `translateX(-${100 - (value ?? 0)}%)` }
	})
}));
Progress.displayName = Root.displayName;
function ConvertView() {
	const library = useAppStore((s) => s.library);
	const addMedia = useAppStore((s) => s.addMedia);
	const playItem = useAppStore((s) => s.playItem);
	const fileRef = (0, import_react.useRef)(null);
	const [file, setFile] = (0, import_react.useState)(null);
	const [label, setLabel] = (0, import_react.useState)("");
	const [format, setFormat] = (0, import_react.useState)("mp3");
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const videos = library.filter((m) => m.kind === "video" && !m.hidden);
	async function pickLibrary(id) {
		const item = library.find((m) => m.id === id);
		if (!item) return;
		setError(null);
		if (item.blobId) {
			const blob = await getMediaBlob(item.blobId);
			if (blob) {
				setFile(blob);
				setLabel(item.title);
				return;
			}
		}
		if (item.url) try {
			const res = await fetch(`/api/media?url=${encodeURIComponent(item.url)}`);
			if (!res.ok) throw new Error("Could not fetch video");
			setFile(await res.blob());
			setLabel(item.title);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not load that video");
		}
	}
	async function run() {
		if (!file) return;
		setBusy(true);
		setError(null);
		setProgress(0);
		try {
			const out = await convertToAudio(file, format, setProgress);
			const base = (label || "audio").replace(/\.[^.]+$/, "");
			downloadBlob(out.blob, `${base}.${out.ext}`);
			const item = await saveBlobAsMedia(out.blob, {
				title: `${base}`,
				kind: "audio",
				platform: "Converted"
			});
			addMedia(item);
			playItem(item.id);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not decode audio from this file. Try another video.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg px-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pt-6 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: "Video to MP3"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Extract audio from any video on this device"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => fileRef.current?.click(),
				className: "flex min-h-[180px] w-full flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-border bg-card px-4 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-14 items-center justify-center rounded-2xl bg-tile-convert text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music4, { className: "size-7" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: label || "Drop or choose a video"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "MP4, WebM, MOV, MKV"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: "video/*,audio/*",
				className: "hidden",
				onChange: (e) => {
					const f = e.target.files?.[0];
					if (!f) return;
					setFile(f);
					setLabel(f.name);
					setError(null);
				}
			}),
			videos.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs tracking-wide text-muted-foreground uppercase",
					children: "From library"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto",
					children: videos.slice(0, 12).map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void pickLibrary(v.id),
						className: "w-28 shrink-0 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-video overflow-hidden rounded-lg bg-subtle",
							children: v.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: v.thumbnail,
								alt: "",
								className: "h-full w-full object-cover"
							}) : null
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate text-[11px]",
							children: v.title
						})]
					}, v.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex gap-2",
				children: ["mp3", "wav"].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFormat(f),
					className: `h-11 flex-1 rounded-lg text-sm uppercase ${format === f ? "bg-primary text-primary-foreground" : "bg-secondary"}`,
					children: f
				}, f))
			}),
			busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
				className: "mt-4",
				value: Math.round(progress * 100)
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-destructive",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-4 w-full",
				disabled: !file || busy,
				onClick: () => void run(),
				children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), busy ? "Converting…" : `Extract ${format.toUpperCase()}`]
			})
		]
	});
}
function DownloadsView() {
	const downloads = useAppStore((s) => s.downloads);
	const removeDownload = useAppStore((s) => s.removeDownload);
	const clearFinished = useAppStore((s) => s.clearFinishedDownloads);
	const playItem = useAppStore((s) => s.playItem);
	const setView = useAppStore((s) => s.setView);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg px-5 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-end justify-between pt-6 pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Downloads"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Saved from the browser and links"
			})] }), downloads.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: clearFinished,
				children: "Clear done"
			}) : null]
		}), downloads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-16 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "mx-auto size-8 text-muted-foreground" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Open Browser, visit a page, and tap Download to save video or audio."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					onClick: () => setView("browser"),
					children: "Open browser"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: downloads.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 flex size-9 items-center justify-center rounded-lg bg-secondary",
							children: d.status === "downloading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : d.status === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : d.status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4 text-destructive" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: d.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										d.format ?? "Media",
										d.bytes ? ` · ${formatBytes(d.bytes)}` : "",
										d.totalBytes ? ` / ${formatBytes(d.totalBytes)}` : ""
									]
								}),
								d.status === "downloading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
									className: "mt-2",
									value: Math.round(d.progress * 100)
								}) : null,
								d.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-destructive",
									children: d.error
								}) : null
							]
						}),
						d.mediaId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => playItem(d.mediaId),
							children: "Play"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-9 items-center justify-center text-muted-foreground",
							"aria-label": "Remove",
							onClick: () => removeDownload(d.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})
					]
				})
			}, d.id))
		})]
	});
}
async function hashPin(pin) {
	const data = new TextEncoder().encode(`onyx-pulse:${pin}`);
	const buf = await crypto.subtle.digest("SHA-256", data);
	return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function MediaCard({ item, onPlay, onHold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onPlay,
		onContextMenu: (e) => {
			if (!onHold) return;
			e.preventDefault();
			onHold();
		},
		className: "group flex flex-col overflow-hidden rounded-xl bg-card text-left shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-200 hover:shadow-[var(--shadow-border-hover)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-video overflow-hidden bg-subtle",
			children: [
				item.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: item.thumbnail,
					alt: "",
					className: "h-full w-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full w-full items-center justify-center font-display text-2xl text-muted-foreground",
					children: item.title.slice(0, 1)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute inset-0 flex items-center justify-center bg-black/0 opacity-0 transition-opacity group-hover:bg-black/30 group-hover:opacity-100",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-11 items-center justify-center rounded-full bg-primary text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 translate-x-px" })
					})
				}),
				item.duration ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute right-2 bottom-2 rounded-md bg-black/70 px-1.5 py-0.5 text-[10px] tabular-nums text-white",
					children: formatTime(item.duration)
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-3 py-2.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm font-medium",
				children: item.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("truncate text-xs text-muted-foreground"),
				children: item.artist ?? item.platform ?? (item.kind === "audio" ? "Audio" : "Video")
			})]
		})]
	});
}
function HiddenView() {
	const pinHash = useAppStore((s) => s.hiddenPinHash);
	const unlocked = useAppStore((s) => s.hiddenUnlocked);
	const setHash = useAppStore((s) => s.setHiddenPinHash);
	const setUnlocked = useAppStore((s) => s.setHiddenUnlocked);
	const library = useAppStore((s) => s.library);
	const playItem = useAppStore((s) => s.playItem);
	const updateMedia = useAppStore((s) => s.updateMedia);
	const [pin, setPin] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const hidden = library.filter((m) => m.hidden);
	async function submit() {
		if (pin.length < 4) {
			setError("Use at least 4 digits");
			return;
		}
		const hash = await hashPin(pin);
		if (!pinHash) {
			setHash(hash);
			setUnlocked(true);
			setPin("");
			setError(null);
			return;
		}
		if (hash !== pinHash) {
			setError("Incorrect PIN");
			return;
		}
		setUnlocked(true);
		setPin("");
		setError(null);
	}
	if (!unlocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-sm flex-col items-center px-5 pt-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-16 items-center justify-center rounded-2xl bg-tile-hidden text-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-7" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-5 text-2xl font-semibold",
				children: "Hidden"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: pinHash ? "Enter your PIN to open the vault." : "Set a PIN to protect private titles."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "password",
				inputMode: "numeric",
				value: pin,
				onChange: (e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 8)),
				placeholder: "PIN",
				className: "mt-6 text-center tracking-[0.4em]",
				onKeyDown: (e) => {
					if (e.key === "Enter") submit();
				}
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-destructive",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4 w-full",
				onClick: () => void submit(),
				children: pinHash ? "Unlock" : "Create PIN"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-5xl px-5 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-end justify-between pt-6 pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Hidden"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [hidden.length, " private titles"]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => setUnlocked(false),
				children: "Lock"
			})]
		}), hidden.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-16 flex flex-col items-center text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-8 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: "Long-press a title in the library and choose Move to Hidden."
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
			children: hidden.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaCard, {
					item,
					onPlay: () => playItem(item.id)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-1 text-xs text-muted-foreground hover:text-foreground",
					onClick: () => updateMedia(item.id, { hidden: false }),
					children: "Restore to library"
				})]
			}, item.id))
		})]
	});
}
var tiles = [
	{
		id: "themes",
		title: "Themes",
		tone: "bg-tile-themes text-white",
		icon: Image
	},
	{
		id: "convert",
		title: "Video to MP3",
		tone: "bg-tile-convert text-white",
		icon: Music4
	},
	{
		id: "hidden",
		title: "Hidden",
		tone: "bg-tile-hidden text-white",
		icon: EyeOff
	},
	{
		id: "downloads",
		title: "Downloads",
		tone: "bg-tile-downloads text-white",
		icon: Download
	}
];
var rows = [
	{
		id: "settings",
		title: "Settings",
		icon: Settings
	},
	{
		id: "transfer",
		title: "File Transfer",
		icon: FolderInput
	},
	{
		id: "widgets",
		title: "Widgets",
		icon: LayoutGrid
	}
];
function HomeView() {
	const setView = useAppStore((s) => s.setView);
	const widgets = useAppStore((s) => s.widgets);
	const library = useAppStore((s) => s.library);
	const downloads = useAppStore((s) => s.downloads);
	const streams = useAppStore((s) => s.streams);
	const playItem = useAppStore((s) => s.playItem);
	const { current } = usePlayer();
	const playing = useAppStore((s) => s.playing);
	const recent = library.filter((m) => !m.hidden).slice(0, 4);
	const activeDl = downloads.filter((d) => d.status === "downloading");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg px-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pt-6 pb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.18em] text-muted-foreground uppercase",
					children: "Player & Browser"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-1 text-3xl font-semibold tracking-tight",
					children: "Onyx Pulse"
				})]
			}),
			widgets.nowPlaying && current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setView("player"),
				className: "mb-5 flex w-full items-center gap-3 rounded-2xl bg-card p-3 text-left shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-14 overflow-hidden rounded-xl bg-subtle",
					children: current.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: current.thumbnail,
						alt: "",
						className: "h-full w-full object-cover"
					}) : null
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-wide text-muted-foreground uppercase",
							children: "Now playing"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-medium",
							children: current.title
						}),
						playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Visualizer, { className: "mt-1 h-6 w-full" }) : null
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3",
				children: tiles.map((tile) => {
					const Icon = tile.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setView(tile.id),
						className: cn("relative flex min-h-[132px] flex-col items-start justify-between overflow-hidden rounded-2xl p-4 text-left transition-transform duration-200 active:scale-[0.98]", tile.tone),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg font-semibold",
							children: tile.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute right-3 bottom-3 flex size-14 items-center justify-center rounded-xl bg-white/20",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-7",
								strokeWidth: 1.75
							})
						})]
					}, tile.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 space-y-1",
				children: rows.map((row) => {
					const Icon = row.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setView(row.id),
						className: "flex h-14 w-full items-center gap-4 rounded-xl px-1 text-left hover:bg-secondary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-11 items-center justify-center rounded-lg text-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-6",
									strokeWidth: 1.6
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 font-display text-lg",
								children: row.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-muted-foreground" })
						]
					}, row.id);
				})
			}),
			widgets.continueWatching && recent.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-display text-sm font-semibold tracking-wide text-muted-foreground uppercase",
					children: "Continue"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-3 overflow-x-auto pb-1",
					children: recent.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => playItem(item.id),
						className: "w-36 shrink-0 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-video overflow-hidden rounded-lg bg-subtle",
							children: item.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.thumbnail,
								alt: "",
								className: "h-full w-full object-cover"
							}) : null
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 truncate text-xs",
							children: item.title
						})]
					}, item.id))
				})]
			}) : null,
			widgets.downloads && activeDl.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground uppercase",
					children: "Active downloads"
				}), activeDl.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 truncate text-sm",
					children: [
						d.title,
						" · ",
						Math.round(d.progress * 100),
						"%"
					]
				}, d.id))]
			}) : null,
			widgets.liveRadio && streams[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setView("streams"),
				className: "mt-4 w-full rounded-2xl bg-card p-4 text-left shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground uppercase",
					children: "Live radio"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg",
					children: streams[0].name
				})]
			}) : null
		]
	});
}
function LibraryView() {
	const library = useAppStore((s) => s.library);
	const addMedia = useAppStore((s) => s.addMedia);
	const removeMedia = useAppStore((s) => s.removeMedia);
	const playItem = useAppStore((s) => s.playItem);
	const fileRef = (0, import_react.useRef)(null);
	const [q, setQ] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [url, setUrl] = (0, import_react.useState)("");
	const [extract, setExtract] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [menu, setMenu] = (0, import_react.useState)(null);
	const items = (0, import_react.useMemo)(() => {
		const visible = library.filter((m) => !m.hidden);
		const byKind = filter === "all" ? visible : visible.filter((m) => m.kind === filter);
		const query = q.trim().toLowerCase();
		if (!query) return byKind;
		return byKind.filter((m) => m.title.toLowerCase().includes(query) || (m.artist ?? "").toLowerCase().includes(query) || (m.platform ?? "").toLowerCase().includes(query));
	}, [
		library,
		filter,
		q
	]);
	async function onFiles(files) {
		if (!files?.length) return;
		for (const file of [...files]) {
			const kind = file.type.startsWith("audio") ? "audio" : "video";
			const item = await saveBlobAsMedia(file, {
				title: file.name.replace(/\.[^.]+$/, ""),
				kind,
				platform: "Device"
			});
			addMedia(item);
		}
	}
	async function addFromUrl() {
		const href = normalizeUrl(url);
		if (!href) return;
		setBusy(true);
		try {
			if (isDirectMediaUrl(href)) {
				const id = uid("media");
				addMedia({
					id,
					title: decodeURIComponent(href.split("/").pop()?.split("?")[0] ?? "Media"),
					kind: mediaKindFromUrl(href),
					source: "url",
					url: href,
					createdAt: Date.now(),
					platform: detectPlatform(href)
				});
				setUrl("");
				playItem(id);
				return;
			}
			const res = await fetch("/api/extract", {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({ url: href })
			});
			const data = await res.json();
			if (!res.ok) throw new Error(data.error ?? "Could not read that link");
			setExtract(data);
			setOpen(true);
			setUrl("");
		} catch {
			const id = uid("media");
			addMedia({
				id,
				title: href,
				kind: "video",
				source: "embed",
				url: href,
				createdAt: Date.now(),
				platform: detectPlatform(href),
				embedUrl: toEmbedUrl(href)
			});
			setUrl("");
		} finally {
			setBusy(false);
		}
	}
	async function remove(item) {
		if (item.blobId) await deleteMediaBlob(item.blobId).catch(() => void 0);
		removeMedia(item.id);
		setMenu(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-5xl px-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-3 pt-6 pb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl font-semibold",
						children: "Library"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [items.length, " titles"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: () => fileRef.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), "Import"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "video/*,audio/*",
						multiple: true,
						className: "hidden",
						onChange: (e) => void onFiles(e.target.files)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Search library",
						className: "pl-9"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 rounded-lg bg-secondary p-1",
					children: [
						"all",
						"video",
						"audio"
					].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(f),
						className: `h-9 rounded-md px-3 text-xs capitalize ${filter === f ? "bg-card shadow-[var(--shadow-border)]" : "text-muted-foreground"}`,
						children: f
					}, f))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-3 flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					addFromUrl();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: url,
						onChange: (e) => setUrl(e.target.value),
						placeholder: "Paste a video, audio, or page URL",
						className: "pl-9"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy || !url.trim(),
					children: "Add"
				})]
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg",
					children: "Library is empty"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Import files from this device or paste a link."
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
				children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaCard, {
					item,
					onPlay: () => playItem(item.id, items.map((m) => m.id)),
					onHold: () => setMenu(item)
				}, item.id))
			}),
			menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-4 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display font-semibold",
							children: menu.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-xs text-muted-foreground",
							children: "Long-press options"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: () => {
								playItem(menu.id);
								setMenu(null);
							},
							children: "Play"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "mt-2 w-full",
							onClick: () => {
								useAppStore.getState().updateMedia(menu.id, { hidden: true });
								setMenu(null);
							},
							children: "Move to Hidden"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "destructive",
							className: "mt-2 w-full",
							onClick: () => void remove(menu),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Remove"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "mt-2 w-full",
							onClick: () => setMenu(null),
							children: "Cancel"
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExtractDialog, {
				open,
				onOpenChange: setOpen,
				result: extract
			})
		]
	});
}
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full bg-secondary shadow-[var(--shadow-border)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring data-[state=checked]:bg-primary", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-0.5 rounded-full bg-foreground shadow-sm transition-transform data-[state=checked]:translate-x-[22px] data-[state=checked]:bg-primary-foreground" })
}));
Switch.displayName = Switch$1.displayName;
function SettingsView() {
	const settings = useAppStore((s) => s.settings);
	const setSettings = useAppStore((s) => s.setSettings);
	const setView = useAppStore((s) => s.setView);
	function row(label, hint, key, on) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center justify-between gap-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-sm font-medium",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted-foreground",
				children: hint
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
				checked: on,
				onCheckedChange: (v) => setSettings({ [key]: v })
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg px-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pt-6 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: "Settings"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Playback, browser, and equalizer"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-card px-4 shadow-[var(--shadow-border)]",
				children: [
					row("Autoplay", "Start the next title when one ends", "autoplay", settings.autoplay),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-border" }),
					row("Resume", "Remember place in a title", "resumePlayback", settings.resumePlayback),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-border" }),
					row("Brave Shields", "Strip known trackers in the browser", "shields", settings.shields),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-border" }),
					row("Equalizer", "Apply the selected tone shape", "eqEnabled", settings.eqEnabled)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs tracking-wide text-muted-foreground uppercase",
					children: "Search engine"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						"brave",
						"duckduckgo",
						"startpage"
					].map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSettings({ searchEngine: e }),
						className: `h-11 rounded-lg text-xs capitalize ${settings.searchEngine === e ? "bg-primary text-primary-foreground" : "bg-secondary"}`,
						children: e === "duckduckgo" ? "DuckDuckGo" : e === "startpage" ? "Startpage" : "Brave"
					}, e))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs tracking-wide text-muted-foreground uppercase",
					children: "Equalizer preset"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						"flat",
						"bass",
						"voice",
						"treble",
						"night"
					].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSettings({
							eqPreset: p,
							eqEnabled: true
						}),
						className: `h-11 rounded-lg text-xs capitalize ${settings.eqPreset === p ? "bg-primary text-primary-foreground" : "bg-secondary"}`,
						children: p
					}, p))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "mt-6 w-full",
				onClick: () => setView("themes"),
				children: "Open themes"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-center text-xs text-muted-foreground",
				children: "Onyx Pulse · Video & audio player"
			})
		]
	});
}
function StreamsView() {
	const streams = useAppStore((s) => s.streams);
	const addStream = useAppStore((s) => s.addStream);
	const removeStream = useAppStore((s) => s.removeStream);
	const addMedia = useAppStore((s) => s.addMedia);
	const playItem = useAppStore((s) => s.playItem);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [url, setUrl] = (0, import_react.useState)("");
	function playStream(id) {
		const s = streams.find((x) => x.id === id);
		if (!s) return;
		const mediaId = `streammedia_${s.id}`;
		addMedia({
			id: mediaId,
			title: s.name,
			kind: s.kind === "audio" ? "audio" : "video",
			source: "url",
			url: s.url,
			createdAt: Date.now(),
			platform: detectPlatform(s.url),
			embedUrl: toEmbedUrl(s.url)
		});
		playItem(mediaId);
	}
	function create() {
		const href = url.trim();
		if (!href) return;
		const kind = isHlsUrl(href) ? "hls" : mediaKindFromUrl(href) === "audio" ? "audio" : toEmbedUrl(href) ? "embed" : "video";
		addStream({
			id: uid("stream"),
			name: name.trim() || "Untitled stream",
			url: href,
			kind,
			createdAt: Date.now()
		});
		setName("");
		setUrl("");
		setOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg px-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pt-6 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold text-primary",
					children: "Streams"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Live radio, HLS, and direct feeds"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setOpen(true),
				className: "flex min-h-[168px] w-full flex-col items-center justify-center gap-3 rounded-2xl border border-border bg-transparent text-primary transition-colors hover:bg-secondary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "size-10",
					strokeWidth: 1.5
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-lg text-foreground",
					children: "New stream"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 space-y-3",
				children: streams.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 rounded-2xl bg-card p-3 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => playStream(s.id),
						className: "flex min-w-0 flex-1 items-center gap-3 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-12 items-center justify-center rounded-xl bg-secondary text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate font-medium",
								children: s.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs text-muted-foreground uppercase",
								children: s.kind
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-full text-muted-foreground hover:text-destructive",
						"aria-label": `Remove ${s.name}`,
						onClick: () => removeStream(s.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				}, s.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New stream" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: url,
							onChange: (e) => setUrl(e.target.value),
							placeholder: "https://… m3u8, mp3, mp4, or page"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: create,
							disabled: !url.trim(),
							children: "Add stream"
						})
					]
				})] })
			})
		]
	});
}
var THEMES = [
	{
		id: "onyx",
		name: "Onyx",
		desc: "Mineral dark, stone accent",
		swatch: [
			"#09090b",
			"#121214",
			"#d4d0c8"
		]
	},
	{
		id: "ivory",
		name: "Ivory",
		desc: "Paper light, ink type",
		swatch: [
			"#f3f1ec",
			"#fffcf7",
			"#2a2926"
		]
	},
	{
		id: "slate",
		name: "Slate",
		desc: "Cool night blue-gray",
		swatch: [
			"#0c1016",
			"#141a22",
			"#b7c4d4"
		]
	},
	{
		id: "ember",
		name: "Ember",
		desc: "Warm dark, copper accent",
		swatch: [
			"#120e0c",
			"#1c1612",
			"#e0703c"
		]
	},
	{
		id: "forest",
		name: "Forest",
		desc: "Deep green mineral",
		swatch: [
			"#0c120f",
			"#141c18",
			"#8fbfa4"
		]
	},
	{
		id: "noir",
		name: "Noir",
		desc: "True black, high contrast",
		swatch: [
			"#000000",
			"#0d0d0d",
			"#f5f5f5"
		]
	}
];
function ThemesView() {
	const theme = useAppStore((s) => s.theme);
	const setTheme = useAppStore((s) => s.setTheme);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg px-5 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "pt-6 pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Themes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Appearance for the whole app"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3",
			children: THEMES.map((t) => {
				const active = theme === t.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTheme(t.id),
					className: cn("flex items-center gap-4 rounded-2xl bg-card p-4 text-left shadow-[var(--shadow-border)]", active && "ring-1 ring-primary"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex overflow-hidden rounded-lg",
							children: t.swatch.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "h-12 w-7",
								style: { background: c }
							}, c))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-lg",
								children: t.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm text-muted-foreground",
								children: t.desc
							})]
						}),
						active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5 text-primary" }) : null
					]
				}, t.id);
			})
		})]
	});
}
function TransferView() {
	const library = useAppStore((s) => s.library);
	const addMedia = useAppStore((s) => s.addMedia);
	const fileRef = (0, import_react.useRef)(null);
	const [status, setStatus] = (0, import_react.useState)(null);
	const visible = library.filter((m) => !m.hidden);
	async function exportAll() {
		setStatus("Preparing files…");
		const payload = {
			exportedAt: Date.now(),
			items: visible.map((m) => ({
				title: m.title,
				artist: m.artist,
				kind: m.kind,
				url: m.url,
				platform: m.platform,
				embedUrl: m.embedUrl,
				thumbnail: m.thumbnail
			}))
		};
		const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
		const a = document.createElement("a");
		a.href = URL.createObjectURL(blob);
		a.download = "onyx-pulse-library.json";
		a.click();
		setStatus("Library list exported. Local files can be sent one by one below.");
	}
	async function sendOne(id) {
		const item = library.find((m) => m.id === id);
		if (!item) return;
		if (item.blobId) {
			const blob = await getMediaBlob(item.blobId);
			if (blob) {
				const a = document.createElement("a");
				a.href = URL.createObjectURL(blob);
				a.download = `${item.title}.${item.kind === "audio" ? "mp3" : "mp4"}`;
				a.click();
				return;
			}
		}
		if (item.url) window.open(item.url, "_blank");
	}
	async function receive(files) {
		if (!files?.length) return;
		let n = 0;
		for (const file of [...files]) {
			if (file.name.endsWith(".json")) {
				try {
					const data = JSON.parse(await file.text());
					for (const it of data.items ?? []) {
						if (!it.url && !it.embedUrl) continue;
						addMedia({
							id: `imp_${Math.random().toString(36).slice(2)}`,
							title: it.title,
							kind: it.kind ?? "video",
							source: "url",
							url: it.url ?? "",
							embedUrl: it.embedUrl,
							createdAt: Date.now(),
							platform: "Imported"
						});
						n += 1;
					}
				} catch {}
				continue;
			}
			const item = await saveBlobAsMedia(file, {
				title: file.name.replace(/\.[^.]+$/, ""),
				kind: file.type.startsWith("audio") ? "audio" : "video",
				platform: "Received"
			});
			addMedia(item);
			n += 1;
		}
		setStatus(`Added ${n} item${n === 1 ? "" : "s"} to the library.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg px-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pt-6 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: "File Transfer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Send titles out or receive files into the library"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void exportAll(),
						className: "flex items-center gap-4 rounded-2xl bg-card p-4 text-left shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-12 items-center justify-center rounded-xl bg-secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: "Export library list"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: "JSON catalog you can import later"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => fileRef.current?.click(),
						className: "flex items-center gap-4 rounded-2xl bg-card p-4 text-left shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-12 items-center justify-center rounded-xl bg-secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: "Receive files"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: "Videos, audio, or an exported list"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						multiple: true,
						className: "hidden",
						onChange: (e) => void receive(e.target.files)
					})
				]
			}),
			status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted-foreground",
				children: status
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 mb-2 font-display text-sm tracking-wide text-muted-foreground uppercase",
				children: "Send a title"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-1",
				children: visible.slice(0, 20).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-xl px-1 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 flex-1 truncate text-sm",
						children: m.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => void sendOne(m.id),
						children: "Send"
					})]
				}, m.id))
			})
		]
	});
}
var ITEMS = [
	{
		key: "nowPlaying",
		title: "Now playing",
		hint: "Show the current title on Home"
	},
	{
		key: "continueWatching",
		title: "Continue",
		hint: "Recent library strip on Home"
	},
	{
		key: "quickConvert",
		title: "Quick convert",
		hint: "Reserved for Home shortcuts"
	},
	{
		key: "downloads",
		title: "Downloads",
		hint: "Active download progress on Home"
	},
	{
		key: "liveRadio",
		title: "Live radio",
		hint: "Pin the first stream on Home"
	}
];
function WidgetsView() {
	const widgets = useAppStore((s) => s.widgets);
	const setWidgets = useAppStore((s) => s.setWidgets);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg px-5 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "pt-6 pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Widgets"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Choose what appears on the home screen"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-2xl bg-card px-4 shadow-[var(--shadow-border)]",
			children: ITEMS.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [i > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-border" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center justify-between gap-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-medium",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted-foreground",
					children: item.hint
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: widgets[item.key],
					onCheckedChange: (v) => setWidgets({ [item.key]: v })
				})]
			})] }, item.key))
		})]
	});
}
var NAV = [
	{
		id: "home",
		label: "Home",
		icon: House
	},
	{
		id: "library",
		label: "Library",
		icon: FolderOpen
	},
	{
		id: "browser",
		label: "Browser",
		icon: Compass
	},
	{
		id: "streams",
		label: "Streams",
		icon: Radio
	}
];
function AppShell() {
	const view = useAppStore((s) => s.view);
	const setView = useAppStore((s) => s.setView);
	const theme = useAppStore((s) => s.theme);
	const seedIfNeeded = useAppStore((s) => s.seedIfNeeded);
	const current = useAppStore((s) => s.currentId);
	(0, import_react.useEffect)(() => {
		seedIfNeeded();
	}, [seedIfNeeded]);
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = theme;
	}, [theme]);
	const showNav = view !== "player";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "atmosphere flex min-h-dvh flex-col bg-background text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-0 w-full max-w-6xl flex-1 flex-col md:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden w-56 shrink-0 flex-col border-r border-border px-3 py-6 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display px-2 text-lg font-semibold",
						children: "Onyx Pulse"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 text-[11px] text-muted-foreground",
						children: "Player · Brave browser"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-6 flex flex-col gap-1",
						children: NAV.map((item) => {
							const Icon = item.icon;
							const active = view === item.id || item.id === "library" && view === "player";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setView(item.id),
								className: cn("flex h-11 items-center gap-3 rounded-lg px-3 text-sm", active ? "bg-secondary font-medium" : "text-muted-foreground hover:bg-secondary/60"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
							}, item.id);
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: cn("flex min-h-0 flex-1 flex-col overflow-y-auto", showNav && current ? "pb-0" : ""),
						children: [
							view === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {}),
							view === "library" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryView, {}),
							view === "browser" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowserView, {}),
							view === "streams" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StreamsView, {}),
							view === "themes" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemesView, {}),
							view === "convert" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConvertView, {}),
							view === "hidden" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HiddenView, {}),
							view === "downloads" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadsView, {}),
							view === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}),
							view === "transfer" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransferView, {}),
							view === "widgets" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WidgetsView, {}),
							view === "player" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FullPlayer, {})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniPlayer, {}),
					showNav ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "grid grid-cols-4 border-t border-border bg-card/95 pb-[env(safe-area-inset-bottom)] md:hidden",
						children: NAV.map((item) => {
							const Icon = item.icon;
							const active = view === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setView(item.id),
								className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[11px]", active ? "text-foreground" : "text-muted-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									strokeWidth: active ? 2.2 : 1.7
								}), item.label]
							}, item.id);
						})
					}) : null
				]
			})]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {}) });
}
//#endregion
export { Home as component };
